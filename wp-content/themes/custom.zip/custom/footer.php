<?php
/**
 * The template for displaying the footer
 *
 * Contains the opening of the #site-footer div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package WordPress
 * @subpackage Twenty_Twenty
 * @since 1.0.0
 */

?>
			<footer id="site-footer" role="contentinfo" class="header-footer-group">
				<div class="section-inner">

					<div class="footer-credits">
                        <div class="ftr">
	                      <div class="container">
							  <div class="row">
								  <div class="col-md-6">
									  <div class="ftr_tx">
										 
									  </div>
								  </div>
								  <div class="col-md-6">
									  
								  </div>
							  </div>
							</div>
						</div>
						
					</div><!-- .footer-credits -->

					

				</div><!-- .section-inner -->

			</footer><!-- #site-footer -->

		<?php wp_footer(); ?>

	</body>
</html>
